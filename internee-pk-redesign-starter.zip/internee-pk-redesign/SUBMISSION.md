# Submission

- **LinkedIn Post URL:** _paste here_
- **GitHub Repository URL:** _paste here_
- **Live Deployment URL (optional):** _paste here_

## Notes (optional)
_Add any comments, decisions, or trade-offs you made during the redesign._
