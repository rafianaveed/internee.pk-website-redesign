# internee.pk – Redesign (React + Vite)

A clean, responsive, and accessible React redesign for **internee.pk**.  
Covers: responsive UI, interactive components, animations, client-side validation, code quality, testing, CI, and deployment.

## 1) Getting Started

### Prerequisites
- Node.js 18+ and npm

### Install & Run
```bash
npm install
npm run dev
```

### Build
```bash
npm run build
npm run preview
```

## 2) Project Structure
```
internee-pk-redesign/
├─ src/
│  ├─ components/       # Navbar, Hero, Features, Slider, ContactForm, Footer
│  ├─ sections/         # Jobs (lazy-loaded)
│  ├─ data/             # Jobs JSON
│  ├─ styles/           # Global CSS
│  ├─ test/             # Vitest + Testing Library
│  ├─ App.jsx
│  └─ main.jsx
├─ public/              # (optional) static assets
├─ .github/workflows/   # CI pipeline
├─ index.html
├─ package.json
└─ README.md
```

## 3) Responsive Design & UI
- **Mobile-first CSS** with a flexible grid and accessible, sticky navigation.
- **Responsive Navbar**: desktop links + animated mobile menu.
- **Cards/Grid**: scales 1–3 columns via media queries.
- **Focus states** and keyboard-friendly controls.

## 4) Interactive & Dynamic UI
- **Framer Motion** for subtle entrance/expand animations (Navbar + Hero).
- **Accessible Slider** with auto-advance and dot controls.
- **Dynamic Content Loading**: `Jobs` section is lazy-loaded (code-splitting).

## 5) Form Validation & UX
- Client-side validation with **react-hook-form** + **zod** schema.
- Clear error messages (`role="alert"`) and `noValidate` to retain control.
- Success state with `role="status"`; ready to POST to your backend.

## 6) Code Quality & Testing
- **ESLint** set up with `eslint:recommended` + `plugin:react/recommended`.
- **Vitest** + **@testing-library/react** unit tests for key components.
- Run: `npm run lint`, `npm test`.

## 7) CI (GitHub Actions)
A minimal CI pipeline runs lint, tests, and build on every push/PR.

## 8) Deployment
- **Vercel** or **Netlify**: import repo, framework = Vite, build = `npm run build`, output = `dist`.
- **GitHub Pages**: build locally and publish `dist/` via GitHub Pages.
  - If using a subpath, set `base` in `vite.config.js` to `'/REPO_NAME/'`.

## 9) Accessibility
- Semantic roles/labels, keyboard operable menus, visible focus outlines, and ARIA for carousel and statuses.

## 10) Where to put your URLs
Fill **SUBMISSION.md** with your LinkedIn, GitHub repo, and Live deployment URLs.

---

### Scripts
- `npm run dev` — start dev server
- `npm run build` — production build to `dist/`
- `npm run preview` — preview the build
- `npm run lint` — lint sources
- `npm test` — run unit tests (CI friendly)
