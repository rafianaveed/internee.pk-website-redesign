import { render, screen, fireEvent } from '@testing-library/react'
import React from 'react'
import Navbar from '../components/Navbar.jsx'

describe('Navbar', () => {
  it('toggles mobile menu', () => {
    render(<Navbar />)
    const btn = screen.getByRole('button', { name: /menu/i })
    fireEvent.click(btn)
    expect(screen.getByRole('menuitem', { name: /home/i })).toBeInTheDocument()
    fireEvent.click(screen.getByRole('link', { name: /features/i }))
  })
})
