import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import React from 'react'
import ContactForm from '../components/ContactForm.jsx'

function typeInto(el, value) {
  fireEvent.change(el, { target: { value } })
  fireEvent.blur(el)
}

describe('ContactForm', () => {
  it('validates and submits', async () => {
    render(<ContactForm />)
    fireEvent.click(screen.getByRole('button', { name: /send message/i }))
    expect(await screen.findAllByRole('alert')).toHaveLength(3)

    typeInto(screen.getByLabelText(/name/i), 'Rafia')
    typeInto(screen.getByLabelText(/email/i), 'rafia@example.com')
    typeInto(screen.getByLabelText(/message/i), 'Hello, this is at least 10 chars.')

    fireEvent.click(screen.getByRole('button', { name: /send message/i }))
    await waitFor(() => {
      expect(screen.getByRole('status')).toHaveTextContent(/thanks/i)
    })
  })
})
