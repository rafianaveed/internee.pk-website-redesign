import React, { Suspense, lazy } from 'react'
import { motion } from 'framer-motion'
import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import Features from './components/Features.jsx'
import Slider from './components/Slider.jsx'
import ContactForm from './components/ContactForm.jsx'
import Footer from './components/Footer.jsx'

const Jobs = lazy(() => import('./sections/Jobs.jsx'))

const slides = [
  { title: 'Paid Internships', text: 'Real-world experience with mentors.' },
  { title: 'Learning Tracks', text: 'Frontend, Backend, DevOps & more.' },
  { title: 'Hire Talent', text: 'Companies can find job-ready interns.' },
]

export default function App() {
  return (
    <div>
      <Navbar />
      <main>
        <motion.section className="hero" id="home"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="container">
            <Hero />
          </div>
        </motion.section>

        <section className="section" id="features">
          <div className="container">
            <Features />
          </div>
        </section>

        <section className="section" id="highlights">
          <div className="container">
            <h2>Highlights</h2>
            <p className="muted">Key things users should notice immediately.</p>
            <div style={{ marginTop: '1rem' }}>
              <Slider slides={slides} interval={4000} />
            </div>
          </div>
        </section>

        <section className="section" id="jobs">
          <div className="container">
            <h2>Latest Opportunities</h2>
            <p className="muted">Dynamically loaded content with code-splitting.</p>
            <Suspense fallback={<p className="muted">Loading jobs…</p>}>
              <Jobs />
            </Suspense>
          </div>
        </section>

        <section className="section" id="contact">
          <div className="container">
            <h2>Contact Us</h2>
            <p className="muted">We’d love to hear from you. All fields are validated on the client.</p>
            <ContactForm />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
