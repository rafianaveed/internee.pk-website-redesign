import React from 'react'
import jobs from '../data/jobs.json'

export default function Jobs() {
  return (
    <div className="cards" role="list">
      {jobs.map(job => (
        <article key={job.id} className="card" role="listitem">
          <h3>{job.title}</h3>
          <p className="muted">{job.company} • {job.type} • {job.location}</p>
          <p style={{ marginTop: '.5rem' }}>{job.summary}</p>
          <a className="cta" href="#" style={{ marginTop: '.75rem' }} aria-label={`Apply for ${job.title}`}>
            Apply
          </a>
        </article>
      ))}
    </div>
  )
}
