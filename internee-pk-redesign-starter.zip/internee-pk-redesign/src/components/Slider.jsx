import React, { useEffect, useRef, useState } from 'react'

export default function Slider({ slides = [], interval = 5000 }) {
  const [index, setIndex] = useState(0)
  const trackRef = useRef(null)

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % slides.length)
    }, interval)
    return () => clearInterval(id)
  }, [interval, slides.length])

  useEffect(() => {
    if (trackRef.current) {
      trackRef.current.style.transform = `translateX(-${index * 100}%)`
    }
  }, [index])

  if (!slides.length) return null

  return (
    <div className="slider" role="region" aria-roledescription="carousel" aria-label="Highlights">
      <div className="slider-track" ref={trackRef}>
        {slides.map((s, i) => (
          <div className="slide" role="group" aria-roledescription="slide" aria-label={`${i+1} of ${slides.length}`} key={i}>
            <h3>{s.title}</h3>
            <p className="muted">{s.text}</p>
          </div>
        ))}
      </div>
      <div className="slider-controls">
        {slides.map((_, i) => (
          <button
            key={i}
            className="dot-btn"
            aria-current={i === index}
            aria-label={`Go to slide ${i + 1}`}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </div>
  )
}
