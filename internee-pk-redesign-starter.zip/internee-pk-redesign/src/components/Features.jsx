import React from 'react'

const items = [
  { title: 'Responsive by default', text: 'Mobile-first layout, flexible grid, and accessible navigation.' },
  { title: 'Interactive UI', text: 'Subtle animations and transitions that respect user preferences.' },
  { title: 'Fast & Lightweight', text: 'Code-splitting and lazy loading to ship just what users need.' },
  { title: 'Client-side Validation', text: 'Prevent invalid submissions and guide users with clear errors.' },
  { title: 'Tested Components', text: 'Vitest + Testing Library for confidence in every change.' },
  { title: 'Deploy Anywhere', text: 'Works on Vercel, Netlify, or GitHub Pages with one command.' },
]

export default function Features() {
  return (
    <div className="cards" role="list">
      {items.map((it) => (
        <article key={it.title} className="card" role="listitem">
          <h3>{it.title}</h3>
          <p className="muted">{it.text}</p>
        </article>
      ))}
    </div>
  )
}
