import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const links = [
  { href: '#home', label: 'Home' },
  { href: '#features', label: 'Features' },
  { href: '#highlights', label: 'Highlights' },
  { href: '#jobs', label: 'Jobs' },
  { href: '#contact', label: 'Contact' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <nav className="navbar" aria-label="Primary">
      <div className="container navbar-inner">
        <a className="brand" href="#home" aria-label="internee.pk Home">
          <span className="dot" aria-hidden="true" />
          internee.pk
        </a>

        <div className="nav-links" role="menubar">
          {links.map(l => (
            <a key={l.href} role="menuitem" href={l.href}>{l.label}</a>
          ))}
        </div>

        <button
          className="menu-btn mobile-menu"
          aria-haspopup="true"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen(v => !v)}
        >
          {open ? 'Close' : 'Menu'}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <div className="container" style={{ padding: '0 0 1rem' }}>
              <div style={{ display: 'grid', gap: '.5rem' }}>
                {links.map(l => (
                  <a key={l.href} href={l.href} onClick={() => setOpen(false)}>{l.label}</a>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
