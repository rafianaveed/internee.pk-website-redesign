import React from 'react'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <small>© {new Date().getFullYear()} internee.pk — Redesign demo. Built with React + Vite.</small>
      </div>
    </footer>
  )
}
