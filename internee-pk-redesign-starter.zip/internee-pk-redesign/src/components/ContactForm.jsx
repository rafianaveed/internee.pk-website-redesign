import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'

const schema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  email: z.string().email('Please enter a valid email address'),
  subject: z.string().optional(),
  message: z.string().min(10, 'Message must be at least 10 characters'),
})

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false)
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm({
    resolver: zodResolver(schema),
    mode: 'onBlur',
  })

  const onSubmit = async (data) => {
    await new Promise(r => setTimeout(r, 400)) // simulate request
    // Normally you would POST to an API here
    console.log('Contact form submitted:', data)
    setSubmitted(true)
    reset()
  }

  if (submitted) {
    return (
      <p role="status">Thanks! Your message has been sent. We’ll get back to you soon.</p>
    )
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className="field">
        <label htmlFor="name">Name</label>
        <input id="name" type="text" placeholder="Your full name" {...register('name')} required />
        {errors.name && <span className="error" role="alert">{errors.name.message}</span>}
      </div>

      <div className="field">
        <label htmlFor="email">Email</label>
        <input id="email" type="email" placeholder="you@example.com" {...register('email')} required />
        {errors.email && <span className="error" role="alert">{errors.email.message}</span>}
      </div>

      <div className="field">
        <label htmlFor="subject">Subject (optional)</label>
        <input id="subject" type="text" placeholder="How can we help?" {...register('subject')} />
      </div>

      <div className="field">
        <label htmlFor="message">Message</label>
        <textarea id="message" rows="5" placeholder="Tell us a bit more…" {...register('message')} required />
        {errors.message && <span className="error" role="alert">{errors.message.message}</span>}
      </div>

      <button className="cta" type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Sending…' : 'Send message'}
      </button>
    </form>
  )
}
