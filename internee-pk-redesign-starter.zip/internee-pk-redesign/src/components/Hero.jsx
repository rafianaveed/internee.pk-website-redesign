import React from 'react'

export default function Hero() {
  return (
    <div>
      <h1>Launch your tech journey with internee.pk</h1>
      <p>
        A modern, responsive experience for interns and employers—fast, accessible, and built with React.
      </p>
      <a className="cta" href="#features" role="button">Explore Features →</a>
    </div>
  )
}
